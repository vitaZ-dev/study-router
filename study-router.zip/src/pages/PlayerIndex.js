import React from "react";

const PlayerIndex = () => {
  return (
    <div>
      <hr />
      <p>현재 재생중인 곡이 없습니다.</p>
    </div>
  );
};

export default PlayerIndex;
